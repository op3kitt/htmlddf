$(() => {
  require("./map.js");
  require("./characterData.js");
  require("./mapMask.js");
  require("./memo.js");
  require("./magicRange.js");
});