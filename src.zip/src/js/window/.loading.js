$(() => {
  require("./upload.js");
  require("./graveyard.js");
  require("./imageDelete.js");
  require("./mapChange.js");
  require("./mapMask.js");
  require("./chat.js");
  require("./help.js");
});